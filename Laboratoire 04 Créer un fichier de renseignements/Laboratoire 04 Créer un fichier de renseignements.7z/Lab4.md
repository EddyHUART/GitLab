# **Laboratoire 1 Les styles**

## **Présentation**
 >Etudiant au CEGEP du Vieux Montréal, mes études porte sur l'informatique dont l'utilisation des outils bureautiques de MICROSOFT.  
 
## **Description du projet et son objectif**

Dans ce laboratoire, je dois mettre en pratique la mise en page à l’aide des styles Word.<br/> 
Pour y parvenir, je dois:  
• Utiliser un texte de base  
• Sélectionner les styles appropriés  
• Appliquer les outils de style et de mise en page du logiciel   

Il faut créer un rapport sur la technique en informatique au Cégep du Vieux Montréal. Il faut réaliser une courte recherche afin d’achever un court rapport sur la technique. À la fin, le document contiendra une page de garde, une table des matières, un en-tête et un pied de page ainsi qu’une mise en page facilitant la lecture.

## **Contraintes du projet**

1. Réalisation durant la première semaine de cours. 
2. Le laboratoire est remis sur le site Moodle du cours
3. Version Word 2007 ou ultérieur requise

## **Statut de votre projet**

![Version](https://img.shields.io/badge/Version-A_améliorer-f58300)




## **Exigences pour la modification et la lecture du projet**

### **Mise en forme** ###
Vous devez créer vos styles et modifier les styles déjà présents. En aucun cas, vous ne
pouvez utiliser la mise en forme manuelle.  

### **Contenu du document**  ###

 ***Page de garde***
 
Votre page de garde doit contenir les éléments suivants :  

• Votre établissement d’enseignement dans le champ Société  
• Le titre du document dans le champ Titre
• La mention « Réaliser par » dans le champ Auteur  
• La date de réalisation dans le champ Date de publication  

Pour la mise en forme, vous êtes libre d’utiliser votre imagination. Toutefois, vous devez utiliser  
les styles. De plus, même si vous avez un champ, vous pouvez et devez appliquer un style.

 ***Table des matières***  
 Votre table des matières doit être générée automatiquement par Word. De plus, elle doit êtresur une page sans autre contenu.  

***En-tête et pied de page***  
Chaque page de votre document doit contenir un en-tête et un pied de page (à l’exception dela page de garde). Le style est libre à vous. Toutefois, l’en-tête et le pied de page doiventcontenir les éléments suivants :

- Titre du document (utiliser le champ Titre)
- Auteur du document (utiliser le champ Auteur)
- Date de publication (utiliser le champ Date de publication)
- Le numéro de page (doit être généré automatiquement)   

De plus, vous devez avoir au moins un élément dans l’en-tête et dans le pied de page.

## **Captures d’écran du projet**

<span style="color:yellow;font-weight:600;font-size:20px"> Page de garde

![Capture d'écran Page de garde](images/Capture1.png)
___
* * *
<span style="color:yellow;font-weight:600;font-size:20px"> Table des matières

![Capture d'écran Table des matières](images/Capture2.png)
___
* * *
<span style="color:yellow;font-weight:600;font-size:20px"> Introduction

![Capture d'écran Introduction](images/Capture3.png)
___
* * *
<span style="color:yellow;font-weight:600;font-size:20px"> Corps

![Capture d'écran Corps](images/Capture4.png)
___
* * *
<span style="color:yellow;font-weight:600;font-size:20px"> Conclusion

![Capture d'écran Conclusion](images/Capture5.png)
___
* * *
<span style="color:yellow;font-weight:600;font-size:20px">  Bibliographie

![Capture d'écran Bibliographie](images/Capture6.png)
___
* * *
<span style="color:yellow;font-weight:600;font-size:20px">En tête

![Capture d'écran En tête](images/Capture7.png)
___
* * *
## **Bibliographie**

Le lien vers le site du cours est à [cette adresse](https://cvm.moodle.decclic.qc.ca/mod/assign/view.php?id=33199).


Le lien vers la documentation Word est  à [cette adresse](https://support.microsoft.com/fr-fr/word).

Le lien vers le document [docx](https://cvm.moodle.decclic.qc.ca/pluginfile.php/141899/assignsubmission_file/submission_files/17751/Techniques%20de%20linformatique.docx?forcedownload=1).  



## **Table des matières**

| Section     | Niveau    | Position    |Description   |
| :----:  |:----: | :----: |:----:  |
| Page de garde | Section | 0 |Page de garde    |
| Table des matières | Section |1|Table des matières|
| Introduction | Sous-Section |2|Table des matières|
|  La grille de cours et son parcours | Section |3| La grille de cours et son parcours|
|  Les installations et les services du département | Section |9|Les installations et les services du département|
|  Les perspectives d’emploi | Section |10| Les perspectives d’emploi|
|  Les perspectives universitaires | Section |11|Les perspectives universitaires |
|  Conclusion | Section |12|Conclusion|
| Bibliographie | Sous-Section |12|Bibliographie|    
   

- [x] Laboratoire Word  
- [ ] Labo Markdown
- [ ] Labo Git    

> Eddy HUART 19 09 2023
<!-- Eddy HUART 19 09 2023  -->














